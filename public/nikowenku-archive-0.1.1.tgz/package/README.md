# nikowenku-archive

A cross-platform CLI for the Wenku Archive, whose collection focuses mainly on light novels and may include other works.

Requires Node.js 22 or newer. Install from npm with `npm install -g nikowenku-archive`, or install offline from `npm install -g --offline ./nikowenku-archive-0.1.1.tgz`.

The CLI connects to the public Wenku Archive site by default. Set `ARCHIVE_SITE_URL` or pass `--site <url>` to use another server.

For a local library, pass `--local` or `--library <path>`. Without a path it uses `./library` relative to the current working directory.

The Codex Skill command manual is included at `skill/SKILL.md`. Copy it to `.agents/skills/nikowenku-archive/SKILL.md` in a project to enable the Skill there.

On Windows PowerShell, use `Copy-Item (Join-Path (npm root -g) 'nikowenku-archive\skill\SKILL.md') .agents\skills\nikowenku-archive\SKILL.md` after creating the destination directory. On Linux or macOS, use `cp "$(npm root -g)/nikowenku-archive/skill/SKILL.md" .agents/skills/nikowenku-archive/SKILL.md` after `mkdir -p .agents/skills/nikowenku-archive`.

Run `nikowenku-archive --help` to see all commands.
