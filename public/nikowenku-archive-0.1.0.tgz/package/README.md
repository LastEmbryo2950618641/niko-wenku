# nikowenku-archive

Requires Node.js 22 or newer. Install with `npm install -g ./nikowenku-archive-0.1.0.tgz`.

The CLI connects to the public Wenku Archive site by default. Set `ARCHIVE_SITE_URL` or pass `--site <url>` to use another server.

For a local library, pass `--local` or `--library <path>`. Without a path it uses `./library` relative to the current working directory.

Run `nikowenku-archive --help` to see all commands.
